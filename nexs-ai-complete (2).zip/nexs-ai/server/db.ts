import { eq, and, desc, like, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  memories,
  projects,
  conversations,
  messages,
  tasks,
  goals,
  habits,
  notes,
  entities,
  relationships,
  insights,
  files,
  searchHistory,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { nanoid } from "nanoid";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER OPERATIONS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserTheme(userId: number, theme: "light" | "dark") {
  const db = await getDb();
  if (!db) return undefined;

  // Theme is stored in client-side localStorage, not in database
  return getUserById(userId);
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ MEMORY OPERATIONS ============

export async function createMemory(
  userId: number,
  data: {
    type: string;
    title: string;
    content: string;
    summary?: string;
    tags?: string[];
    category?: string;
    source?: string;
    sourceUrl?: string;
    projectId?: string;
    keywords?: string[];
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(memories).values({
    id,
    userId,
    type: data.type as any,
    title: data.title,
    content: data.content,
    summary: data.summary,
    tags: data.tags || [],
    category: data.category,
    source: data.source,
    sourceUrl: data.sourceUrl,
    projectId: data.projectId,
    keywords: data.keywords || [],
    importanceScore: "0.5" as any,
    confidenceScore: "0.8" as any,
  });

  return getMemoryById(id);
}

export async function getMemoryById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(memories).where(eq(memories.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserMemories(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(memories)
    .where(and(eq(memories.userId, userId), eq(memories.isArchived, false)))
    .orderBy(desc(memories.createdAt))
    .limit(limit);
}

export async function searchMemories(userId: number, query: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(memories)
    .where(
      and(
        eq(memories.userId, userId),
        like(memories.title, `%${query}%`)
      )
    )
    .orderBy(desc(memories.importanceScore))
    .limit(20);
}

export async function updateMemory(id: string, data: Partial<typeof memories.$inferInsert>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(memories).set(data).where(eq(memories.id, id));
  return getMemoryById(id);
}

export async function deleteMemory(id: string) {
  const db = await getDb();
  if (!db) return false;

  await db.update(memories).set({ isArchived: true }).where(eq(memories.id, id));
  return true;
}

// ============ PROJECT OPERATIONS ============

export async function createProject(
  userId: number,
  data: {
    name: string;
    description?: string;
    color?: string;
    icon?: string;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(projects).values({
    id,
    userId,
    name: data.name,
    description: data.description,
    color: data.color || "#6366f1",
    icon: data.icon,
  });

  return getProjectById(id);
}

export async function getProjectById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserProjects(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(projects)
    .where(and(eq(projects.userId, userId), eq(projects.status, "active")))
    .orderBy(desc(projects.updatedAt));
}

export async function updateProject(id: string, data: Partial<typeof projects.$inferInsert>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(projects).set(data).where(eq(projects.id, id));
  return getProjectById(id);
}

// ============ CONVERSATION OPERATIONS ============

export async function createConversation(
  userId: number,
  data: {
    title?: string;
    projectId?: string;
    folder?: string;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(conversations).values({
    id,
    userId,
    title: data.title || "New Conversation",
    projectId: data.projectId,
    folder: data.folder,
  });

  return getConversationById(id);
}

export async function getConversationById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.lastMessageAt));
}

// ============ MESSAGE OPERATIONS ============

export async function createMessage(
  conversationId: string,
  userId: number,
  data: {
    role: "user" | "assistant";
    content: string;
    relatedMemoryIds?: string[];
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(messages).values({
    id,
    conversationId,
    userId,
    role: data.role,
    content: data.content,
    relatedMemoryIds: data.relatedMemoryIds || [],
  });

  // Update conversation's lastMessageAt
  await db.update(conversations).set({ lastMessageAt: new Date() }).where(eq(conversations.id, conversationId));

  return getMessageById(id);
}

export async function getMessageById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getConversationMessages(conversationId: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt);
}

// ============ TASK OPERATIONS ============

export async function createTask(
  userId: number,
  data: {
    title: string;
    description?: string;
    projectId?: string;
    priority?: "low" | "medium" | "high" | "urgent";
    dueDate?: Date;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(tasks).values({
    id,
    userId,
    title: data.title,
    description: data.description,
    projectId: data.projectId,
    priority: data.priority || "medium",
    dueDate: data.dueDate,
  });

  return getTaskById(id);
}

export async function getTaskById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.status, "todo")))
    .orderBy(tasks.dueDate);
}

export async function updateTask(id: string, data: Partial<typeof tasks.$inferInsert>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(tasks).set(data).where(eq(tasks.id, id));
  return getTaskById(id);
}

// ============ GOAL OPERATIONS ============

export async function createGoal(
  userId: number,
  data: {
    title: string;
    description?: string;
    category?: string;
    targetDate?: Date;
    projectId?: string;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(goals).values({
    id,
    userId,
    title: data.title,
    description: data.description,
    category: data.category,
    targetDate: data.targetDate,
    projectId: data.projectId,
  });

  return getGoalById(id);
}

export async function getGoalById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(goals).where(eq(goals.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserGoals(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(goals)
    .where(and(eq(goals.userId, userId), eq(goals.status, "active")))
    .orderBy(desc(goals.targetDate));
}

export async function updateGoal(id: string, data: Partial<typeof goals.$inferInsert>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(goals).set(data).where(eq(goals.id, id));
  return getGoalById(id);
}

// ============ HABIT OPERATIONS ============

export async function createHabit(
  userId: number,
  data: {
    title: string;
    description?: string;
    frequency?: "daily" | "weekly" | "monthly";
    category?: string;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(habits).values({
    id,
    userId,
    title: data.title,
    description: data.description,
    frequency: data.frequency || "daily",
    category: data.category,
  });

  return getHabitById(id);
}

export async function getHabitById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(habits).where(eq(habits.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserHabits(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(habits)
    .where(and(eq(habits.userId, userId), eq(habits.isActive, true)))
    .orderBy(desc(habits.currentStreak));
}

export async function logHabitCompletion(habitId: string, date: string) {
  const db = await getDb();
  if (!db) return undefined;

  const habit = await getHabitById(habitId);
  if (!habit) return undefined;

  const completedDates = (habit.completedDates as string[]) || [];
  if (!completedDates.includes(date)) {
    completedDates.push(date);
  }

  await db.update(habits).set({ completedDates }).where(eq(habits.id, habitId));
  return getHabitById(habitId);
}

// ============ NOTE OPERATIONS ============

export async function createNote(
  userId: number,
  data: {
    title: string;
    content: string;
    projectId?: string;
    tags?: string[];
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(notes).values({
    id,
    userId,
    title: data.title,
    content: data.content,
    projectId: data.projectId,
    tags: data.tags || [],
  });

  return getNoteById(id);
}

export async function getNoteById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(notes).where(eq(notes.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserNotes(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(notes)
    .where(and(eq(notes.userId, userId), eq(notes.isArchived, false)))
    .orderBy(desc(notes.updatedAt));
}

export async function updateNote(id: string, data: Partial<typeof notes.$inferInsert>) {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(notes).set(data).where(eq(notes.id, id));
  return getNoteById(id);
}

// ============ ENTITY OPERATIONS ============

export async function createEntity(
  userId: number,
  data: {
    type: string;
    name: string;
    description?: string;
    metadata?: Record<string, unknown>;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(entities).values({
    id,
    userId,
    type: data.type as any,
    name: data.name,
    description: data.description,
    metadata: data.metadata || {},
  });

  return getEntityById(id);
}

export async function getEntityById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(entities).where(eq(entities.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserEntities(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(entities).where(eq(entities.userId, userId));
}

// ============ RELATIONSHIP OPERATIONS ============

export async function createRelationship(
  userId: number,
  data: {
    sourceEntityId: string;
    targetEntityId: string;
    type: string;
    strength?: number;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(relationships).values({
    id,
    userId,
    sourceEntityId: data.sourceEntityId,
    targetEntityId: data.targetEntityId,
    type: data.type,
    strength: (data.strength || 0.5).toString() as any,
  });

  return getRelationshipById(id);
}

export async function getRelationshipById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(relationships).where(eq(relationships.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getEntityRelationships(userId: number, entityId: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(relationships)
    .where(
      and(
        eq(relationships.userId, userId),
        inArray(relationships.sourceEntityId, [entityId])
      )
    );
}

// ============ INSIGHT OPERATIONS ============

export async function createInsight(
  userId: number,
  data: {
    type: "weekly_summary" | "monthly_digest" | "suggestion" | "pattern";
    title: string;
    content: string;
    relatedMemoryIds?: string[];
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(insights).values({
    id,
    userId,
    type: data.type,
    title: data.title,
    content: data.content,
    relatedMemoryIds: data.relatedMemoryIds || [],
  });

  return getInsightById(id);
}

export async function getInsightById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(insights).where(eq(insights.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserInsights(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(insights)
    .where(eq(insights.userId, userId))
    .orderBy(desc(insights.generatedAt))
    .limit(20);
}

// ============ FILE OPERATIONS ============

export async function createFile(
  userId: number,
  data: {
    filename: string;
    mimeType?: string;
    fileSize?: number;
    fileKey: string;
    url: string;
    projectId?: string;
    memoryId?: string;
  }
) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(files).values({
    id,
    userId,
    filename: data.filename,
    mimeType: data.mimeType,
    fileSize: data.fileSize,
    fileKey: data.fileKey,
    url: data.url,
    projectId: data.projectId,
    memoryId: data.memoryId,
  });

  return getFileById(id);
}

export async function getFileById(id: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(files).where(eq(files.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserFiles(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(files).where(eq(files.userId, userId)).orderBy(desc(files.createdAt));
}

// ============ SEARCH HISTORY OPERATIONS ============

export async function logSearch(userId: number, query: string, resultCount: number) {
  const db = await getDb();
  if (!db) return undefined;

  const id = nanoid();
  await db.insert(searchHistory).values({
    id,
    userId,
    query,
    resultCount,
  });

  return true;
}
