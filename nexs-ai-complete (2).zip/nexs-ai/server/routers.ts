import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: router({
    health: publicProcedure.query(() => ({ status: "ok" })),
  }),

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    updateTheme: protectedProcedure
      .input(z.enum(["light", "dark"]))
      .mutation(async ({ ctx, input }) => {
        return await db.updateUserTheme(ctx.user.id, input);
      }),
  }),

  // ============ MEMORY OPERATIONS ============

  memory: router({
    create: protectedProcedure
      .input(
        z.object({
          type: z.string(),
          title: z.string(),
          content: z.string(),
          summary: z.string().optional(),
          tags: z.array(z.string()).optional(),
          category: z.string().optional(),
          source: z.string().optional(),
          sourceUrl: z.string().optional(),
          projectId: z.string().optional(),
          keywords: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createMemory(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getMemoryById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserMemories(ctx.user.id);
    }),

    search: protectedProcedure
      .input(z.string())
      .query(async ({ ctx, input }) => {
        return await db.searchMemories(ctx.user.id, input);
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.string(),
          title: z.string().optional(),
          content: z.string().optional(),
          tags: z.array(z.string()).optional(),
          importanceScore: z.number().optional(),
          isPinned: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateMemory(id, data as any);
      }),

    delete: protectedProcedure
      .input(z.string())
      .mutation(async ({ input }) => {
        return await db.deleteMemory(input);
      }),
  }),

  // ============ PROJECT OPERATIONS ============

  project: router({
    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          description: z.string().optional(),
          color: z.string().optional(),
          icon: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createProject(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getProjectById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserProjects(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.string(),
          name: z.string().optional(),
          description: z.string().optional(),
          progress: z.number().optional(),
          status: z.enum(["active", "archived", "completed"]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateProject(id, data as any);
      }),
  }),

  // ============ CONVERSATION OPERATIONS ============

  conversation: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().optional(),
          projectId: z.string().optional(),
          folder: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createConversation(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getConversationById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserConversations(ctx.user.id);
    }),
  }),

  // ============ MESSAGE OPERATIONS ============

  message: router({
    create: protectedProcedure
      .input(
        z.object({
          conversationId: z.string(),
          role: z.enum(["user", "assistant"]),
          content: z.string(),
          relatedMemoryIds: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createMessage(input.conversationId, ctx.user.id, {
          role: input.role,
          content: input.content,
          relatedMemoryIds: input.relatedMemoryIds,
        });
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getMessageById(input);
      }),

    listByConversation: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getConversationMessages(input);
      }),
  }),

  // ============ TASK OPERATIONS ============

  task: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          description: z.string().optional(),
          projectId: z.string().optional(),
          priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
          dueDate: z.date().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createTask(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getTaskById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserTasks(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.string(),
          title: z.string().optional(),
          status: z.enum(["todo", "in_progress", "completed", "cancelled"]).optional(),
          priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
          dueDate: z.date().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateTask(id, data as any);
      }),
  }),

  // ============ GOAL OPERATIONS ============

  goal: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          description: z.string().optional(),
          category: z.string().optional(),
          targetDate: z.date().optional(),
          projectId: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createGoal(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getGoalById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserGoals(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.string(),
          title: z.string().optional(),
          progress: z.number().optional(),
          status: z.enum(["active", "completed", "abandoned"]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateGoal(id, data as any);
      }),
  }),

  // ============ HABIT OPERATIONS ============

  habit: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          description: z.string().optional(),
          frequency: z.enum(["daily", "weekly", "monthly"]).optional(),
          category: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createHabit(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getHabitById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserHabits(ctx.user.id);
    }),

    logCompletion: protectedProcedure
      .input(
        z.object({
          habitId: z.string(),
          date: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.logHabitCompletion(input.habitId, input.date);
      }),
  }),

  // ============ NOTE OPERATIONS ============

  note: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string(),
          content: z.string(),
          projectId: z.string().optional(),
          tags: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createNote(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getNoteById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserNotes(ctx.user.id);
    }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.string(),
          title: z.string().optional(),
          content: z.string().optional(),
          tags: z.array(z.string()).optional(),
          isPinned: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateNote(id, data as any);
      }),
  }),

  // ============ ENTITY OPERATIONS ============

  entity: router({
    create: protectedProcedure
      .input(
        z.object({
          type: z.string(),
          name: z.string(),
          description: z.string().optional(),
          metadata: z.record(z.string(), z.unknown()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createEntity(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getEntityById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserEntities(ctx.user.id);
    }),
  }),

  // ============ RELATIONSHIP OPERATIONS ============

  relationship: router({
    create: protectedProcedure
      .input(
        z.object({
          sourceEntityId: z.string(),
          targetEntityId: z.string(),
          type: z.string(),
          strength: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createRelationship(ctx.user.id, input);
      }),

    getEntityRelationships: protectedProcedure
      .input(z.string())
      .query(async ({ ctx, input }) => {
        return await db.getEntityRelationships(ctx.user.id, input);
      }),
  }),

  // ============ INSIGHT OPERATIONS ============

  insight: router({
    create: protectedProcedure
      .input(
        z.object({
          type: z.enum(["weekly_summary", "monthly_digest", "suggestion", "pattern"]),
          title: z.string(),
          content: z.string(),
          relatedMemoryIds: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createInsight(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getInsightById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserInsights(ctx.user.id);
    }),
  }),

  // ============ FILE OPERATIONS ============

  file: router({
    create: protectedProcedure
      .input(
        z.object({
          filename: z.string(),
          mimeType: z.string().optional(),
          fileSize: z.number().optional(),
          fileKey: z.string(),
          url: z.string(),
          projectId: z.string().optional(),
          memoryId: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.createFile(ctx.user.id, input);
      }),

    getById: protectedProcedure
      .input(z.string())
      .query(async ({ input }) => {
        return await db.getFileById(input);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserFiles(ctx.user.id);
    }),
  }),

  // ============ SEARCH OPERATIONS ============

  search: router({
    logQuery: protectedProcedure
      .input(
        z.object({
          query: z.string(),
          resultCount: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await db.logSearch(ctx.user.id, input.query, input.resultCount);
      }),

    universal: protectedProcedure
      .input(z.string())
      .query(async ({ ctx, input }) => {
        const query = input.toLowerCase();

        // Search across all memory types
        const memories = await db.searchMemories(ctx.user.id, query);
        const projects = await db.getUserProjects(ctx.user.id);
        const tasks = await db.getUserTasks(ctx.user.id);
        const goals = await db.getUserGoals(ctx.user.id);
        const notes = await db.getUserNotes(ctx.user.id);

        // Filter and combine results
        const results = {
          memories: memories.slice(0, 5),
          projects: projects.filter((p) => p.name.toLowerCase().includes(query)).slice(0, 5),
          tasks: tasks.filter((t) => t.title.toLowerCase().includes(query)).slice(0, 5),
          goals: goals.filter((g) => g.title.toLowerCase().includes(query)).slice(0, 5),
          notes: notes.filter((n) => n.title.toLowerCase().includes(query)).slice(0, 5),
        };

        // Log the search
        const resultCount = Object.values(results).flat().length;
        await db.logSearch(ctx.user.id, input, resultCount);

        return results;
      }),
  }),
});

export type AppRouter = typeof appRouter;
