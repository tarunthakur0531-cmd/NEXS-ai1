import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  decimal,
  json,
  longtext,
  mediumtext,
} from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Memories - Core memory storage with all metadata
 */
export const memories = mysqlTable("memories", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", [
    "conversation",
    "idea",
    "goal",
    "task",
    "note",
    "document",
    "project",
    "person",
    "company",
    "website",
    "research",
    "code",
    "meeting",
    "bookmark",
    "other",
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: longtext("content").notNull(),
  summary: mediumtext("summary"),
  tags: json("tags").$type<string[]>().default([]),
  category: varchar("category", { length: 100 }),
  source: varchar("source", { length: 100 }),
  sourceUrl: text("sourceUrl"),
  importanceScore: decimal("importanceScore", { precision: 3, scale: 2 }).default("0.5"),
  confidenceScore: decimal("confidenceScore", { precision: 3, scale: 2 }).default("0.8"),
  keywords: json("keywords").$type<string[]>().default([]),
  embeddings: longtext("embeddings"),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  context: mediumtext("context"),
  projectId: varchar("projectId", { length: 64 }),
  isArchived: boolean("isArchived").default(false),
  isPinned: boolean("isPinned").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type Memory = typeof memories.$inferSelect;
export type InsertMemory = typeof memories.$inferInsert;

/**
 * Projects - Workspace for organizing related memories and tasks
 */
export const projects = mysqlTable("projects", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: mediumtext("description"),
  color: varchar("color", { length: 7 }).default("#6366f1"),
  icon: varchar("icon", { length: 50 }),
  status: mysqlEnum("status", ["active", "archived", "completed"]).default("active"),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  progress: int("progress").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

/**
 * Conversations - Chat history with AI
 */
export const conversations = mysqlTable("conversations", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  projectId: varchar("projectId", { length: 64 }),
  title: varchar("title", { length: 255 }).default("New Conversation"),
  isPinned: boolean("isPinned").default(false),
  folder: varchar("folder", { length: 100 }),
  lastMessageAt: timestamp("lastMessageAt").defaultNow(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages - Individual messages in conversations
 */
export const messages = mysqlTable("messages", {
  id: varchar("id", { length: 64 }).primaryKey(),
  conversationId: varchar("conversationId", { length: 64 }).notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: longtext("content").notNull(),
  isStreaming: boolean("isStreaming").default(false),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  metadata: json("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Tasks - Task management with priorities and deadlines
 */
export const tasks = mysqlTable("tasks", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  projectId: varchar("projectId", { length: 64 }),
  title: varchar("title", { length: 255 }).notNull(),
  description: mediumtext("description"),
  status: mysqlEnum("status", ["todo", "in_progress", "completed", "cancelled"]).default("todo"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium"),
  dueDate: timestamp("dueDate"),
  completedAt: timestamp("completedAt"),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  subtasks: json("subtasks").$type<Array<{ id: string; title: string; completed: boolean }>>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Goals - Long-term goals with progress tracking
 */
export const goals = mysqlTable("goals", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  projectId: varchar("projectId", { length: 64 }),
  title: varchar("title", { length: 255 }).notNull(),
  description: mediumtext("description"),
  category: varchar("category", { length: 100 }),
  targetDate: timestamp("targetDate"),
  progress: int("progress").default(0),
  status: mysqlEnum("status", ["active", "completed", "abandoned"]).default("active"),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  relatedTaskIds: json("relatedTaskIds").$type<string[]>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Goal = typeof goals.$inferSelect;
export type InsertGoal = typeof goals.$inferInsert;

/**
 * Habits - Daily/weekly habit tracking
 */
export const habits = mysqlTable("habits", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: mediumtext("description"),
  frequency: mysqlEnum("frequency", ["daily", "weekly", "monthly"]).default("daily"),
  category: varchar("category", { length: 100 }),
  currentStreak: int("currentStreak").default(0),
  longestStreak: int("longestStreak").default(0),
  completedDates: json("completedDates").$type<string[]>().default([]),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = typeof habits.$inferInsert;

/**
 * Notes - Rich text notes with formatting
 */
export const notes = mysqlTable("notes", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  projectId: varchar("projectId", { length: 64 }),
  title: varchar("title", { length: 255 }).notNull(),
  content: longtext("content").notNull(),
  tags: json("tags").$type<string[]>().default([]),
  isPinned: boolean("isPinned").default(false),
  isArchived: boolean("isArchived").default(false),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Note = typeof notes.$inferSelect;
export type InsertNote = typeof notes.$inferInsert;

/**
 * Knowledge Graph Entities - Nodes in the knowledge graph
 */
export const entities = mysqlTable("entities", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["person", "project", "idea", "goal", "task", "document", "company", "other"]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: mediumtext("description"),
  metadata: json("metadata").$type<Record<string, unknown>>().default({}),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Entity = typeof entities.$inferSelect;
export type InsertEntity = typeof entities.$inferInsert;

/**
 * Knowledge Graph Relationships - Edges between entities
 */
export const relationships = mysqlTable("relationships", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  sourceEntityId: varchar("sourceEntityId", { length: 64 }).notNull(),
  targetEntityId: varchar("targetEntityId", { length: 64 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  strength: decimal("strength", { precision: 3, scale: 2 }).default("0.5"),
  metadata: json("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Relationship = typeof relationships.$inferSelect;
export type InsertRelationship = typeof relationships.$inferInsert;

/**
 * Insights - Generated insights and summaries
 */
export const insights = mysqlTable("insights", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["weekly_summary", "monthly_digest", "suggestion", "pattern"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: longtext("content").notNull(),
  relatedMemoryIds: json("relatedMemoryIds").$type<string[]>().default([]),
  isRead: boolean("isRead").default(false),
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Insight = typeof insights.$inferSelect;
export type InsertInsight = typeof insights.$inferInsert;

/**
 * Search History - Track user searches for analytics
 */
export const searchHistory = mysqlTable("searchHistory", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  query: varchar("query", { length: 500 }).notNull(),
  resultCount: int("resultCount").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SearchHistory = typeof searchHistory.$inferSelect;
export type InsertSearchHistory = typeof searchHistory.$inferInsert;

/**
 * Files - File storage metadata
 */
export const files = mysqlTable("files", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  projectId: varchar("projectId", { length: 64 }),
  memoryId: varchar("memoryId", { length: 64 }),
  filename: varchar("filename", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  fileKey: varchar("fileKey", { length: 255 }).notNull(),
  url: text("url").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;

/**
 * Relations for type safety
 */
export const usersRelations = relations(users, ({ many }) => ({
  memories: many(memories),
  projects: many(projects),
  conversations: many(conversations),
  messages: many(messages),
  tasks: many(tasks),
  goals: many(goals),
  habits: many(habits),
  notes: many(notes),
  entities: many(entities),
  relationships: many(relationships),
  insights: many(insights),
  files: many(files),
}));

export const memoriesRelations = relations(memories, ({ one, many }) => ({
  user: one(users, {
    fields: [memories.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [memories.projectId],
    references: [projects.id],
  }),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  user: one(users, {
    fields: [projects.userId],
    references: [users.id],
  }),
  memories: many(memories),
  conversations: many(conversations),
  tasks: many(tasks),
  goals: many(goals),
  notes: many(notes),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  user: one(users, {
    fields: [conversations.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [conversations.projectId],
    references: [projects.id],
  }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  user: one(users, {
    fields: [messages.userId],
    references: [users.id],
  }),
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  user: one(users, {
    fields: [tasks.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
  }),
}));

export const goalsRelations = relations(goals, ({ one }) => ({
  user: one(users, {
    fields: [goals.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [goals.projectId],
    references: [projects.id],
  }),
}));

export const habitsRelations = relations(habits, ({ one }) => ({
  user: one(users, {
    fields: [habits.userId],
    references: [users.id],
  }),
}));

export const notesRelations = relations(notes, ({ one }) => ({
  user: one(users, {
    fields: [notes.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [notes.projectId],
    references: [projects.id],
  }),
}));

export const entitiesRelations = relations(entities, ({ one, many }) => ({
  user: one(users, {
    fields: [entities.userId],
    references: [users.id],
  }),
  outgoingRelationships: many(relationships),
}));

export const relationshipsRelations = relations(relationships, ({ one }) => ({
  user: one(users, {
    fields: [relationships.userId],
    references: [users.id],
  }),
  sourceEntity: one(entities, {
    fields: [relationships.sourceEntityId],
    references: [entities.id],
  }),
  targetEntity: one(entities, {
    fields: [relationships.targetEntityId],
    references: [entities.id],
  }),
}));

export const insightsRelations = relations(insights, ({ one }) => ({
  user: one(users, {
    fields: [insights.userId],
    references: [users.id],
  }),
}));

export const filesRelations = relations(files, ({ one }) => ({
  user: one(users, {
    fields: [files.userId],
    references: [users.id],
  }),
  project: one(projects, {
    fields: [files.projectId],
    references: [projects.id],
  }),
  memory: one(memories, {
    fields: [files.memoryId],
    references: [memories.id],
  }),
}));
