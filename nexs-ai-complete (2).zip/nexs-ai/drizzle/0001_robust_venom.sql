CREATE TABLE `conversations` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`projectId` varchar(64),
	`title` varchar(255) DEFAULT 'New Conversation',
	`isPinned` boolean DEFAULT false,
	`folder` varchar(100),
	`lastMessageAt` timestamp DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `entities` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`type` enum('person','project','idea','goal','task','document','company','other') NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` mediumtext,
	`metadata` json DEFAULT ('{}'),
	`relatedMemoryIds` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `entities_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `files` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`projectId` varchar(64),
	`memoryId` varchar(64),
	`filename` varchar(255) NOT NULL,
	`mimeType` varchar(100),
	`fileSize` int,
	`fileKey` varchar(255) NOT NULL,
	`url` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `goals` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`projectId` varchar(64),
	`title` varchar(255) NOT NULL,
	`description` mediumtext,
	`category` varchar(100),
	`targetDate` timestamp,
	`progress` int DEFAULT 0,
	`status` enum('active','completed','abandoned') DEFAULT 'active',
	`relatedMemoryIds` json DEFAULT ('[]'),
	`relatedTaskIds` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `goals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `habits` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` mediumtext,
	`frequency` enum('daily','weekly','monthly') DEFAULT 'daily',
	`category` varchar(100),
	`currentStreak` int DEFAULT 0,
	`longestStreak` int DEFAULT 0,
	`completedDates` json DEFAULT ('[]'),
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `habits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `insights` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`type` enum('weekly_summary','monthly_digest','suggestion','pattern') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` longtext NOT NULL,
	`relatedMemoryIds` json DEFAULT ('[]'),
	`isRead` boolean DEFAULT false,
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `insights_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `memories` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`type` enum('conversation','idea','goal','task','note','document','project','person','company','website','research','code','meeting','bookmark','other') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` longtext NOT NULL,
	`summary` mediumtext,
	`tags` json DEFAULT ('[]'),
	`category` varchar(100),
	`source` varchar(100),
	`sourceUrl` text,
	`importanceScore` decimal(3,2) DEFAULT '0.5',
	`confidenceScore` decimal(3,2) DEFAULT '0.8',
	`keywords` json DEFAULT ('[]'),
	`embeddings` longtext,
	`relatedMemoryIds` json DEFAULT ('[]'),
	`context` mediumtext,
	`projectId` varchar(64),
	`isArchived` boolean DEFAULT false,
	`isPinned` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `memories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` varchar(64) NOT NULL,
	`conversationId` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` longtext NOT NULL,
	`isStreaming` boolean DEFAULT false,
	`relatedMemoryIds` json DEFAULT ('[]'),
	`metadata` json DEFAULT ('{}'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notes` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`projectId` varchar(64),
	`title` varchar(255) NOT NULL,
	`content` longtext NOT NULL,
	`tags` json DEFAULT ('[]'),
	`isPinned` boolean DEFAULT false,
	`isArchived` boolean DEFAULT false,
	`relatedMemoryIds` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` mediumtext,
	`color` varchar(7) DEFAULT '#6366f1',
	`icon` varchar(50),
	`status` enum('active','archived','completed') DEFAULT 'active',
	`startDate` timestamp,
	`endDate` timestamp,
	`progress` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `relationships` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`sourceEntityId` varchar(64) NOT NULL,
	`targetEntityId` varchar(64) NOT NULL,
	`type` varchar(100) NOT NULL,
	`strength` decimal(3,2) DEFAULT '0.5',
	`metadata` json DEFAULT ('{}'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `relationships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `searchHistory` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`query` varchar(500) NOT NULL,
	`resultCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `searchHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`projectId` varchar(64),
	`title` varchar(255) NOT NULL,
	`description` mediumtext,
	`status` enum('todo','in_progress','completed','cancelled') DEFAULT 'todo',
	`priority` enum('low','medium','high','urgent') DEFAULT 'medium',
	`dueDate` timestamp,
	`completedAt` timestamp,
	`relatedMemoryIds` json DEFAULT ('[]'),
	`subtasks` json DEFAULT ('[]'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `avatar` text;--> statement-breakpoint
ALTER TABLE `users` ADD `bio` text;--> statement-breakpoint
ALTER TABLE `users` ADD `theme` enum('light','dark') DEFAULT 'dark' NOT NULL;