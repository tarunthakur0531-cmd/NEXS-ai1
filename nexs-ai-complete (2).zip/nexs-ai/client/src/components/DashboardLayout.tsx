import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { trpc } from "@/lib/trpc";
import { useTheme } from "@/contexts/ThemeContext";
import { motion } from "framer-motion";
import {
  Brain,
  MessageSquare,
  Network,
  Settings,
  LogOut,
  Moon,
  Sun,
  Menu,
  X,
  Calendar,
  BookOpen,
  Zap,
} from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const logoutMutation = trpc.auth.logout.useMutation();
  const updateThemeMutation = trpc.auth.updateTheme.useMutation();

  const navItems = [
    { icon: Brain, label: "Dashboard", href: "/dashboard" },
    { icon: MessageSquare, label: "Chat", href: "/chat" },
    { icon: Network, label: "Knowledge Graph", href: "/knowledge-graph" },
    { icon: Calendar, label: "Timeline", href: "/timeline" },
    { icon: BookOpen, label: "Projects", href: "/projects" },
    { icon: Zap, label: "Insights", href: "/insights" },
    { icon: Settings, label: "Settings", href: "/settings" },
  ];

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    if (logout) logout();
  };

  const handleThemeToggle = async () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    if (toggleTheme) toggleTheme();
    await updateThemeMutation.mutateAsync(newTheme);
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: 0 }}
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-background/40 backdrop-blur-md border-r border-white/10 flex flex-col transition-all duration-300`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center">
              <Brain className="h-6 w-6 text-white" />
            </div>
            {sidebarOpen && <span className="font-bold text-lg">NEXS AI</span>}
          </motion.div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="hover:bg-white/10"
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </div>

        {/* Navigation */}
        <ScrollArea className="flex-1 p-4">
          <nav className="space-y-2">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <motion.button
                  key={item.href}
                  whileHover={{ x: 4 }}
                  onClick={() => setLocation(item.href)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    isActive
                      ? "bg-blue-600/30 border border-blue-400/50 text-blue-300"
                      : "hover:bg-white/5 border border-transparent text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <item.icon className="h-5 w-5 flex-shrink-0" />
                  {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
                </motion.button>
              );
            })}
          </nav>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleThemeToggle}
            className="w-full justify-start gap-3 hover:bg-white/10"
          >
            {theme === "dark" ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
            {sidebarOpen && <span className="text-sm">{theme === "dark" ? "Light" : "Dark"}</span>}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="w-full justify-start gap-3 hover:bg-red-500/10 text-red-400 hover:text-red-300"
          >
            <LogOut className="h-4 w-4" />
            {sidebarOpen && <span className="text-sm">Logout</span>}
          </Button>

          {sidebarOpen && (
            <div className="pt-2 border-t border-white/10 text-xs text-muted-foreground">
              <p className="truncate">{user?.name}</p>
              <p className="truncate">{user?.email}</p>
            </div>
          )}
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-8"
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}
