import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { Settings, User, Bell, Lock, Trash2, Download } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function SettingsPage() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [isSaving, setIsSaving] = useState(false);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    try {
      // In a real app, you would have an updateProfile mutation
      await new Promise((resolve) => setTimeout(resolve, 500));
      toast.success("Profile updated successfully");
    } catch (error) {
      toast.error("Failed to update profile");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <DashboardLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-6"
      >
        {/* Header */}
        <motion.div variants={itemVariants}>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Settings className="h-8 w-8 text-blue-400" />
            Settings
          </h1>
          <p className="text-muted-foreground mt-2">Manage your account and preferences</p>
        </motion.div>

        {/* Tabs */}
        <motion.div variants={itemVariants}>
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-background/40 backdrop-blur-md border border-white/10 rounded-lg p-1">
              <TabsTrigger value="profile" className="rounded-md">
                Profile
              </TabsTrigger>
              <TabsTrigger value="privacy" className="rounded-md">
                Privacy
              </TabsTrigger>
              <TabsTrigger value="notifications" className="rounded-md">
                Notifications
              </TabsTrigger>
              <TabsTrigger value="data" className="rounded-md">
                Data
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-4 mt-4">
              <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Full Name</label>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your name"
                      className="mt-2 bg-background/40 border-white/10"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Email</label>
                    <Input
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your@email.com"
                      type="email"
                      className="mt-2 bg-background/40 border-white/10"
                    />
                  </div>



                  <Button
                    onClick={handleSaveProfile}
                    disabled={isSaving}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {isSaving ? "Saving..." : "Save Profile"}
                  </Button>
                </div>
              </Card>
            </TabsContent>

            {/* Privacy Tab */}
            <TabsContent value="privacy" className="space-y-4 mt-4">
              <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10">
                    <div>
                      <h3 className="font-semibold">Memory Privacy</h3>
                      <p className="text-sm text-muted-foreground">Control who can see your memories</p>
                    </div>
                    <Button variant="outline" className="border-white/10">
                      Manage
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10">
                    <div>
                      <h3 className="font-semibold">Data Sharing</h3>
                      <p className="text-sm text-muted-foreground">Allow AI to learn from your data</p>
                    </div>
                    <Button variant="outline" className="border-white/10">
                      Configure
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10">
                    <div>
                      <h3 className="font-semibold">Two-Factor Authentication</h3>
                      <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
                    </div>
                    <Button variant="outline" className="border-white/10">
                      Enable
                    </Button>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-4 mt-4">
              <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10">
                <div className="space-y-4">
                  {[
                    { title: "Task Reminders", description: "Get notified about upcoming tasks" },
                    { title: "Goal Progress", description: "Weekly updates on your goal progress" },
                    { title: "Insights", description: "Receive AI-generated insights and suggestions" },
                    { title: "Memory Suggestions", description: "Suggestions to organize your memories" },
                  ].map((notif, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10"
                    >
                      <div>
                        <h3 className="font-semibold">{notif.title}</h3>
                        <p className="text-sm text-muted-foreground">{notif.description}</p>
                      </div>
                      <input type="checkbox" defaultChecked className="w-5 h-5" />
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Data Tab */}
            <TabsContent value="data" className="space-y-4 mt-4">
              <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10">
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Export Your Data
                      </h3>
                      <p className="text-sm text-muted-foreground">Download all your memories and data</p>
                    </div>
                    <Button variant="outline" className="border-white/10">
                      Export
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg bg-red-500/10 border border-red-400/30">
                    <div>
                      <h3 className="font-semibold text-red-400 flex items-center gap-2">
                        <Trash2 className="h-4 w-4" />
                        Delete Account
                      </h3>
                      <p className="text-sm text-muted-foreground">Permanently delete your account and all data</p>
                    </div>
                    <Button variant="outline" className="border-red-400/30 text-red-400 hover:bg-red-500/10">
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Account Info */}
        <motion.div variants={itemVariants}>
          <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10">
            <h3 className="font-semibold mb-4">Account Information</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">User ID</p>
                <p className="font-mono text-xs mt-1">{user?.id}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Member Since</p>
                <p className="font-medium mt-1">
                  {user?.createdAt && new Date(user.createdAt).toLocaleDateString()}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Last Sign In</p>
                <p className="font-medium mt-1">
                  {user?.lastSignedIn && new Date(user.lastSignedIn).toLocaleDateString()}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Account Status</p>
                <p className="font-medium mt-1 text-green-400">Active</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </motion.div>
    </DashboardLayout>
  );
}
