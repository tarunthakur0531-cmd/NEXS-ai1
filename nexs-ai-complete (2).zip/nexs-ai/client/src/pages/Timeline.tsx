import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { Calendar, Filter, Search, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

interface TimelineEvent {
  id: string;
  title: string;
  type: string;
  date: Date;
  content: string;
  icon: string;
}

export default function Timeline() {
  const { user } = useAuth();
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Fetch all data for timeline
  const { data: memories } = trpc.memory.list.useQuery();
  const { data: tasks } = trpc.task.list.useQuery();
  const { data: goals } = trpc.goal.list.useQuery();

  // Combine and sort events
  const events: TimelineEvent[] = [
    ...(memories?.map((m) => ({
      id: m.id,
      title: m.title,
      type: "memory",
      date: new Date(m.createdAt),
      content: m.content,
      icon: "🧠",
    })) || []),
    ...(tasks?.map((t) => ({
      id: t.id,
      title: t.title,
      type: "task",
      date: new Date(t.createdAt),
      content: t.description || "",
      icon: "✓",
    })) || []),
    ...(goals?.map((g) => ({
      id: g.id,
      title: g.title,
      type: "goal",
      date: new Date(g.createdAt),
      content: g.description || "",
      icon: "🎯",
    })) || []),
  ].sort((a, b) => b.date.getTime() - a.date.getTime());

  // Filter events
  const filteredEvents = events.filter((event) => {
    const matchesType = !selectedType || event.type === selectedType;
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const typeColors: Record<string, string> = {
    memory: "from-blue-500 to-blue-600",
    task: "from-green-500 to-green-600",
    goal: "from-purple-500 to-purple-600",
  };

  const typeLabels: Record<string, string> = {
    memory: "Memory",
    task: "Task",
    goal: "Goal",
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Calendar className="h-8 w-8 text-blue-400" />
                Memory Timeline
              </h1>
              <p className="text-muted-foreground mt-2">
                Chronological view of all your memories, tasks, and goals
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-3 flex-wrap">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search timeline..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-background/40 border-white/10 focus:border-blue-400/50"
              />
            </div>

            <div className="flex gap-2">
              {["memory", "task", "goal"].map((type) => (
                <Button
                  key={type}
                  variant={selectedType === type ? "default" : "outline"}
                  onClick={() => setSelectedType(selectedType === type ? null : type)}
                  className={`capitalize ${
                    selectedType === type
                      ? "bg-blue-600 hover:bg-blue-700"
                      : "bg-background/40 border-white/10 hover:bg-white/10"
                  }`}
                >
                  <Filter className="h-4 w-4 mr-2" />
                  {typeLabels[type]}
                </Button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Timeline */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="relative"
        >
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-400 via-purple-400 to-pink-400 rounded-full" />

          {/* Events */}
          <div className="space-y-4">
            {filteredEvents.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
              >
                <Calendar className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                <p className="text-muted-foreground">No events found</p>
              </motion.div>
            ) : (
              filteredEvents.map((event, idx) => (
                <motion.div
                  key={event.id}
                  variants={itemVariants}
                  className="relative pl-24"
                >
                  {/* Timeline dot */}
                  <motion.div
                    className={`absolute left-0 w-16 h-16 rounded-full bg-gradient-to-br ${typeColors[event.type]} flex items-center justify-center text-2xl shadow-lg`}
                    whileHover={{ scale: 1.1 }}
                  >
                    {event.icon}
                  </motion.div>

                  {/* Event card */}
                  <motion.div
                    whileHover={{ x: 4 }}
                    onClick={() =>
                      setExpandedId(expandedId === event.id ? null : event.id)
                    }
                    className="cursor-pointer"
                  >
                    <Card className="p-4 bg-background/40 backdrop-blur-md border-white/10 hover:border-blue-400/30 transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className={`text-xs px-2 py-1 rounded-full bg-gradient-to-r ${typeColors[event.type]} bg-opacity-20`}>
                              {typeLabels[event.type]}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {event.date.toLocaleDateString()} {event.date.toLocaleTimeString()}
                            </span>
                          </div>
                          <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
                          {expandedId === event.id && (
                            <motion.p
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="text-sm text-muted-foreground line-clamp-3"
                            >
                              {event.content}
                            </motion.p>
                          )}
                        </div>
                        <motion.div
                          animate={{ rotate: expandedId === event.id ? 180 : 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          {expandedId === event.id ? (
                            <ChevronUp className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          )}
                        </motion.div>
                      </div>
                    </Card>
                  </motion.div>
                </motion.div>
              ))
            )}
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
