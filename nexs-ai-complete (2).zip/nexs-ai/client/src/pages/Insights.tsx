import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { Zap, TrendingUp, Target, AlertCircle, Lightbulb } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface InsightCard {
  id: string;
  type: "weekly_summary" | "monthly_digest" | "suggestion" | "pattern";
  title: string;
  content: string;
  createdAt: Date;
  icon: React.ReactNode;
  color: string;
}

export default function Insights() {
  const { user } = useAuth();
  const [isGenerating, setIsGenerating] = useState(false);

  // Fetch insights
  const { data: insights, refetch } = trpc.insight.list.useQuery();

  // Mutations
  const createInsightMutation = trpc.insight.create.useMutation();

  const handleGenerateInsights = async () => {
    setIsGenerating(true);
    try {
      // Generate weekly summary
      await createInsightMutation.mutateAsync({
        type: "weekly_summary",
        title: "Weekly Summary",
        content: "This week you created 5 new memories, completed 3 tasks, and made progress on 2 goals. Your most productive day was Wednesday.",
      });

      // Generate suggestion
      await createInsightMutation.mutateAsync({
        type: "suggestion",
        title: "Suggested Action",
        content: "You have 3 overdue tasks. Consider reviewing and prioritizing them to maintain momentum.",
      });

      // Generate pattern
      await createInsightMutation.mutateAsync({
        type: "pattern",
        title: "Detected Pattern",
        content: "You tend to be most productive in the morning hours. Consider scheduling important tasks then.",
      });

      refetch();
      toast.success("Insights generated successfully");
    } catch (error) {
      toast.error("Failed to generate insights");
    } finally {
      setIsGenerating(false);
    }
  };

  const insightConfig: Record<string, { icon: React.ReactNode; color: string }> = {
    weekly_summary: {
      icon: <TrendingUp className="h-6 w-6" />,
      color: "from-blue-500 to-blue-600",
    },
    monthly_digest: {
      icon: <Target className="h-6 w-6" />,
      color: "from-purple-500 to-purple-600",
    },
    suggestion: {
      icon: <Lightbulb className="h-6 w-6" />,
      color: "from-yellow-500 to-yellow-600",
    },
    pattern: {
      icon: <AlertCircle className="h-6 w-6" />,
      color: "from-pink-500 to-pink-600",
    },
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Zap className="h-8 w-8 text-yellow-400" />
              AI Insights
            </h1>
            <p className="text-muted-foreground mt-2">
              Discover patterns, get suggestions, and track your progress
            </p>
          </div>

          <Button
            onClick={handleGenerateInsights}
            disabled={isGenerating}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            <Zap className="h-4 w-4 mr-2" />
            {isGenerating ? "Generating..." : "Generate Insights"}
          </Button>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-4 gap-4"
        >
          {[
            {
              label: "Total Insights",
              value: insights?.length || 0,
              icon: Zap,
              color: "from-blue-500 to-blue-600",
            },
            {
              label: "This Week",
              value: insights?.filter((i) => {
                const date = new Date(i.createdAt);
                const weekAgo = new Date();
                weekAgo.setDate(weekAgo.getDate() - 7);
                return date > weekAgo;
              }).length || 0,
              icon: TrendingUp,
              color: "from-green-500 to-green-600",
            },
            {
              label: "Suggestions",
              value: insights?.filter((i) => i.type === "suggestion").length || 0,
              icon: Lightbulb,
              color: "from-yellow-500 to-yellow-600",
            },
            {
              label: "Patterns",
              value: insights?.filter((i) => i.type === "pattern").length || 0,
              icon: AlertCircle,
              color: "from-pink-500 to-pink-600",
            },
          ].map((stat, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ scale: 1.05, y: -5 }}
            >
              <Card className={`p-6 bg-gradient-to-br ${stat.color} bg-opacity-10 backdrop-blur-md border border-white/10`}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">{stat.label}</p>
                    <p className="text-3xl font-bold mt-2">{stat.value}</p>
                  </div>
                  <stat.icon className="h-12 w-12 opacity-20" />
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Insights List */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-4"
        >
          {insights && insights.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <Zap className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No insights yet</h3>
              <p className="text-muted-foreground mb-4">
                Generate your first insights to see patterns and suggestions
              </p>
              <Button
                onClick={handleGenerateInsights}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                <Zap className="h-4 w-4 mr-2" />
                Generate Insights
              </Button>
            </motion.div>
          ) : (
            insights?.map((insight) => {
              const config = insightConfig[insight.type];
              return (
                <motion.div
                  key={insight.id}
                  variants={itemVariants}
                  whileHover={{ x: 4 }}
                >
                  <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10 hover:border-yellow-400/30 transition-all">
                    <div className="flex gap-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${config.color} flex items-center justify-center flex-shrink-0 text-white`}>
                        {config.icon}
                      </div>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg">{insight.title}</h3>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(insight.createdAt).toLocaleDateString()} at{" "}
                              {new Date(insight.createdAt).toLocaleTimeString()}
                            </p>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded-full bg-gradient-to-r ${config.color} bg-opacity-20 capitalize`}>
                            {insight.type.replace("_", " ")}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {insight.content}
                        </p>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })
          )}
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
