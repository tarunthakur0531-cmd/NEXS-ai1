import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import { Plus, Search, ZoomIn, ZoomOut, Maximize2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface Node {
  id: string;
  name: string;
  type: string;
  x: number;
  y: number;
  vx?: number;
  vy?: number;
}

interface Link {
  source: string;
  target: string;
  type: string;
  strength: number;
}

export default function KnowledgeGraph() {
  const { user } = useAuth();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [links, setLinks] = useState<Link[]>([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch entities
  const { data: entities } = trpc.entity.list.useQuery();

  // Initialize nodes from entities
  useEffect(() => {
    if (entities) {
      const newNodes: Node[] = entities.map((entity, idx) => ({
        id: entity.id,
        name: entity.name,
        type: entity.type,
        x: Math.cos((idx / entities.length) * 2 * Math.PI) * 300,
        y: Math.sin((idx / entities.length) * 2 * Math.PI) * 300,
        vx: 0,
        vy: 0,
      }));
      setNodes(newNodes);
    }
  }, [entities]);

  // Simple force-directed layout
  useEffect(() => {
    const animate = () => {
      setNodes((prevNodes) => {
        const newNodes = prevNodes.map((node) => ({
          ...node,
          vx: (node.vx || 0) * 0.9,
          vy: (node.vy || 0) * 0.9,
        }));

        // Apply repulsion forces between nodes
        for (let i = 0; i < newNodes.length; i++) {
          for (let j = i + 1; j < newNodes.length; j++) {
            const dx = newNodes[j].x - newNodes[i].x;
            const dy = newNodes[j].y - newNodes[i].y;
            const distance = Math.sqrt(dx * dx + dy * dy) || 1;
            const repulsion = 200 / (distance * distance);

            newNodes[i].vx! -= (repulsion * dx) / distance;
            newNodes[i].vy! -= (repulsion * dy) / distance;
            newNodes[j].vx! += (repulsion * dx) / distance;
            newNodes[j].vy! += (repulsion * dy) / distance;
          }
        }

        // Apply link forces
        links.forEach((link) => {
          const sourceNode = newNodes.find((n) => n.id === link.source);
          const targetNode = newNodes.find((n) => n.id === link.target);

          if (sourceNode && targetNode) {
            const dx = targetNode.x - sourceNode.x;
            const dy = targetNode.y - sourceNode.y;
            const distance = Math.sqrt(dx * dx + dy * dy) || 1;
            const attraction = (distance - 100) * 0.1 * link.strength;

            sourceNode.vx! += (attraction * dx) / distance;
            sourceNode.vy! += (attraction * dy) / distance;
            targetNode.vx! -= (attraction * dx) / distance;
            targetNode.vy! -= (attraction * dy) / distance;
          }
        });

        // Update positions with damping
        return newNodes.map((node) => ({
          ...node,
          x: node.x + (node.vx || 0) * 0.5,
          y: node.y + (node.vy || 0) * 0.5,
        }));
      });
    };

    const interval = setInterval(animate, 30);
    return () => clearInterval(interval);
  }, [links]);

  // Draw canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear canvas with gradient
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, "rgba(15, 23, 42, 0.8)");
    gradient.addColorStop(1, "rgba(30, 41, 59, 0.8)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw links
    ctx.strokeStyle = "rgba(100, 116, 139, 0.3)";
    ctx.lineWidth = 1;
    links.forEach((link) => {
      const sourceNode = nodes.find((n) => n.id === link.source);
      const targetNode = nodes.find((n) => n.id === link.target);

      if (sourceNode && targetNode) {
        const x1 = sourceNode.x * zoom + pan.x + canvas.width / 2;
        const y1 = sourceNode.y * zoom + pan.y + canvas.height / 2;
        const x2 = targetNode.x * zoom + pan.x + canvas.width / 2;
        const y2 = targetNode.y * zoom + pan.y + canvas.height / 2;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    });

    // Draw nodes
    nodes.forEach((node) => {
      const x = node.x * zoom + pan.x + canvas.width / 2;
      const y = node.y * zoom + pan.y + canvas.height / 2;

      const isSelected = selectedNode?.id === node.id;
      const radius = isSelected ? 20 : 12;

      // Node circle
      ctx.fillStyle = isSelected
        ? "rgba(59, 130, 246, 0.8)"
        : "rgba(99, 102, 241, 0.6)";
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, 2 * Math.PI);
      ctx.fill();

      // Node border
      ctx.strokeStyle = isSelected ? "rgba(59, 130, 246, 1)" : "rgba(99, 102, 241, 0.8)";
      ctx.lineWidth = isSelected ? 3 : 2;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, 2 * Math.PI);
      ctx.stroke();

      // Node label
      ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
      ctx.font = "12px sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(node.name.substring(0, 10), x, y);
    });
  }, [nodes, links, selectedNode, zoom, pan]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = (e.clientX - rect.left - canvas.width / 2 - pan.x) / zoom;
    const clickY = (e.clientY - rect.top - canvas.height / 2 - pan.y) / zoom;

    // Find clicked node
    for (const node of nodes) {
      const dx = node.x - clickX;
      const dy = node.y - clickY;
      if (Math.sqrt(dx * dx + dy * dy) < 20) {
        setSelectedNode(node);
        return;
      }
    }
    setSelectedNode(null);
  };

  const filteredNodes = nodes.filter((n) =>
    n.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="space-y-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold">Knowledge Graph</h1>
            <p className="text-muted-foreground">
              Visualize connections between your memories, projects, and ideas
            </p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Entity
          </Button>
        </motion.div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Canvas */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="lg:col-span-3 bg-background/40 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden"
          >
            <div className="relative h-[600px]">
              <canvas
                ref={canvasRef}
                width={800}
                height={600}
                onClick={handleCanvasClick}
                className="w-full h-full cursor-pointer"
              />

              {/* Controls */}
              <div className="absolute top-4 right-4 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setZoom((z) => Math.min(z + 0.2, 3))}
                  className="bg-background/40 border-white/10"
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setZoom((z) => Math.max(z - 0.2, 0.5))}
                  className="bg-background/40 border-white/10"
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setZoom(1);
                    setPan({ x: 0, y: 0 });
                  }}
                  className="bg-background/40 border-white/10"
                >
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search entities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-background/40 border-white/10 focus:border-blue-400/50"
              />
            </div>

            {/* Selected Node Info */}
            {selectedNode && (
              <Card className="p-4 bg-background/40 backdrop-blur-md border-white/10">
                <h3 className="font-semibold mb-2">Selected Entity</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <p className="text-muted-foreground">Name</p>
                    <p className="font-medium">{selectedNode.name}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Type</p>
                    <p className="font-medium capitalize">{selectedNode.type}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Connections</p>
                    <p className="font-medium">
                      {links.filter(
                        (l) => l.source === selectedNode.id || l.target === selectedNode.id
                      ).length}
                    </p>
                  </div>
                </div>
              </Card>
            )}

            {/* Entities List */}
            <Card className="p-4 bg-background/40 backdrop-blur-md border-white/10">
              <h3 className="font-semibold mb-3">Entities ({filteredNodes.length})</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredNodes.map((node) => (
                  <motion.button
                    key={node.id}
                    whileHover={{ x: 4 }}
                    onClick={() => setSelectedNode(node)}
                    className={`w-full text-left p-2 rounded-lg text-sm transition-all ${
                      selectedNode?.id === node.id
                        ? "bg-blue-500/20 border border-blue-400/50"
                        : "hover:bg-white/5 border border-transparent"
                    }`}
                  >
                    <p className="font-medium truncate">{node.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{node.type}</p>
                  </motion.button>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </DashboardLayout>
  );
}
