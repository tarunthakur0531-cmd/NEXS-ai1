import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  Brain,
  MessageSquare,
  Search,
  Zap,
  CheckCircle2,
  Target,
  BookOpen,
  Calendar,
  Plus,
  ArrowRight,
} from "lucide-react";
import { useState } from "react";

export default function Dashboard() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch core data
  const { data: memories } = trpc.memory.list.useQuery();
  const { data: projects } = trpc.project.list.useQuery();
  const { data: tasks } = trpc.task.list.useQuery();
  const { data: goals } = trpc.goal.list.useQuery();

  // Search results
  const { data: searchResults } = trpc.search.universal.useQuery(searchQuery, {
    enabled: searchQuery.length > 0,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <DashboardLayout>
      <motion.div
        className="space-y-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header Section */}
        <motion.div variants={itemVariants} className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Welcome back, {user?.name || "User"}
              </h1>
              <p className="text-muted-foreground mt-2">
                Your AI-powered memory and productivity hub
              </p>
            </div>
            <motion.div
              className="text-6xl"
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity } as any}
            >
              <Brain className="text-blue-400" size={48} />
            </motion.div>
          </div>
        </motion.div>

        {/* Universal Search Bar */}
        <motion.div variants={itemVariants}>
          <div className="relative">
            <Search className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search memories, projects, tasks, goals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 py-6 text-base bg-background/40 backdrop-blur-md border border-white/10 rounded-2xl focus:border-blue-400/50 focus:ring-blue-400/20 transition-all"
            />
          </div>
        </motion.div>

        {/* Search Results */}
        {searchResults && searchQuery && (
          <motion.div variants={itemVariants} className="space-y-4">
            <h2 className="text-xl font-semibold">Search Results</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {searchResults.memories.length > 0 && (
                <Card className="p-4 bg-background/40 backdrop-blur-md border-white/10 hover:border-blue-400/30 transition-all">
                  <h3 className="font-semibold text-blue-400 mb-2">Memories</h3>
                  <div className="space-y-2">
                    {searchResults.memories.map((m) => (
                      <div key={m.id} className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                        {m.title}
                      </div>
                    ))}
                  </div>
                </Card>
              )}
              {searchResults.tasks.length > 0 && (
                <Card className="p-4 bg-background/40 backdrop-blur-md border-white/10 hover:border-green-400/30 transition-all">
                  <h3 className="font-semibold text-green-400 mb-2">Tasks</h3>
                  <div className="space-y-2">
                    {searchResults.tasks.map((t) => (
                      <div key={t.id} className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                        {t.title}
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          </motion.div>
        )}

        {/* Quick Stats */}
        <motion.div variants={itemVariants}>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { icon: Brain, label: "Memories", value: memories?.length || 0, color: "from-blue-500 to-blue-600" },
              { icon: Target, label: "Active Goals", value: goals?.length || 0, color: "from-purple-500 to-purple-600" },
              { icon: CheckCircle2, label: "Tasks", value: tasks?.length || 0, color: "from-green-500 to-green-600" },
              { icon: BookOpen, label: "Projects", value: projects?.length || 0, color: "from-orange-500 to-orange-600" },
            ].map((stat, idx) => (
              <motion.div
                key={idx}
                whileHover={{ scale: 1.05, y: -5 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                <Card className={`p-6 bg-gradient-to-br ${stat.color} bg-opacity-10 backdrop-blur-md border border-white/10 hover:border-white/20 transition-all`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground text-sm">{stat.label}</p>
                      <p className="text-3xl font-bold mt-2">{stat.value}</p>
                    </div>
                    <stat.icon className="h-12 w-12 opacity-20" />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Main Content Tabs */}
        <motion.div variants={itemVariants}>
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-background/40 backdrop-blur-md border border-white/10 rounded-lg p-1">
              <TabsTrigger value="overview" className="rounded-md">
                Overview
              </TabsTrigger>
              <TabsTrigger value="memories" className="rounded-md">
                Memories
              </TabsTrigger>
              <TabsTrigger value="tasks" className="rounded-md">
                Tasks
              </TabsTrigger>
              <TabsTrigger value="insights" className="rounded-md">
                Insights
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Recent Memories */}
                <motion.div variants={itemVariants}>
                  <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10 h-full">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold flex items-center gap-2">
                        <Brain className="h-5 w-5 text-blue-400" />
                        Recent Memories
                      </h3>
                      <Button variant="ghost" size="sm">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-3">
                      {memories?.slice(0, 3).map((m) => (
                        <motion.div
                          key={m.id}
                          whileHover={{ x: 4 }}
                          className="p-3 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer transition-colors"
                        >
                          <p className="text-sm font-medium truncate">{m.title}</p>
                          <p className="text-xs text-muted-foreground mt-1">{m.category}</p>
                        </motion.div>
                      ))}
                    </div>
                  </Card>
                </motion.div>

                {/* Active Tasks */}
                <motion.div variants={itemVariants}>
                  <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10 h-full">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-400" />
                        Active Tasks
                      </h3>
                      <Button variant="ghost" size="sm">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-3">
                      {tasks?.slice(0, 3).map((t) => (
                        <motion.div
                          key={t.id}
                          whileHover={{ x: 4 }}
                          className="p-3 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer transition-colors"
                        >
                          <p className="text-sm font-medium truncate">{t.title}</p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-xs text-muted-foreground capitalize">{t.priority}</span>
                            <span className="text-xs text-muted-foreground">{t.status}</span>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </Card>
                </motion.div>

                {/* Goals Progress */}
                <motion.div variants={itemVariants}>
                  <Card className="p-6 bg-background/40 backdrop-blur-md border-white/10 h-full">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold flex items-center gap-2">
                        <Target className="h-5 w-5 text-purple-400" />
                        Goals
                      </h3>
                      <Button variant="ghost" size="sm">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-3">
                      {goals?.slice(0, 3).map((g) => (
                        <motion.div
                          key={g.id}
                          whileHover={{ x: 4 }}
                          className="p-3 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer transition-colors"
                        >
                          <p className="text-sm font-medium truncate">{g.title}</p>
                          <div className="mt-2 bg-white/10 rounded-full h-2">
                            <motion.div
                              className="bg-gradient-to-r from-purple-400 to-purple-600 h-full rounded-full"
                              initial={{ width: 0 }}
                              animate={{ width: `${g.progress}%` }}
                              transition={{ duration: 0.8, ease: "easeOut" }}
                            />
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{g.progress}% complete</p>
                        </motion.div>
                      ))}
                    </div>
                  </Card>
                </motion.div>
              </div>
            </TabsContent>

            {/* Memories Tab */}
            <TabsContent value="memories" className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">All Memories</h3>
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Memory
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {memories?.map((m) => (
                  <motion.div
                    key={m.id}
                    whileHover={{ scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  >
                    <Card className="p-4 bg-background/40 backdrop-blur-md border-white/10 hover:border-blue-400/30 cursor-pointer transition-all">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-semibold truncate flex-1">{m.title}</h4>
                        <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full ml-2">
                          {m.type}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{m.content}</p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Importance: {(parseFloat(m.importanceScore as any) * 100).toFixed(0)}%</span>
                        <span>{m.tags?.length || 0} tags</span>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Tasks Tab */}
            <TabsContent value="tasks" className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">All Tasks</h3>
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Task
                </Button>
              </div>
              <div className="space-y-2">
                {tasks?.map((t) => (
                  <motion.div
                    key={t.id}
                    whileHover={{ x: 4 }}
                    className="p-4 bg-background/40 backdrop-blur-md border border-white/10 rounded-lg hover:border-green-400/30 cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold">{t.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{t.description}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          t.priority === "urgent" ? "bg-red-500/20 text-red-300" :
                          t.priority === "high" ? "bg-orange-500/20 text-orange-300" :
                          t.priority === "medium" ? "bg-yellow-500/20 text-yellow-300" :
                          "bg-blue-500/20 text-blue-300"
                        }`}>
                          {t.priority}
                        </span>
                        <span className="text-xs text-muted-foreground">{t.status}</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Insights Tab */}
            <TabsContent value="insights" className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">AI Insights</h3>
                <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                  <Zap className="h-4 w-4 mr-2" />
                  Generate Insights
                </Button>
              </div>
              <Card className="p-8 bg-gradient-to-br from-purple-500/10 to-blue-500/10 backdrop-blur-md border border-white/10 text-center">
                <Zap className="h-12 w-12 mx-auto text-purple-400 mb-4 opacity-50" />
                <p className="text-muted-foreground">
                  Insights will appear here as you build your memory and complete tasks
                </p>
                <Button className="mt-4 bg-purple-600 hover:bg-purple-700">
                  Generate Your First Insight
                </Button>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </motion.div>
    </DashboardLayout>
  );
}
