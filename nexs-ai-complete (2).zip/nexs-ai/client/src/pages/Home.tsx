import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Brain, MessageSquare, Network, Zap, ArrowRight, Github } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  if (isAuthenticated && !loading) {
    navigate("/dashboard");
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin">
          <Brain className="h-12 w-12 text-blue-400" />
        </div>
      </div>
    );
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-blue-950/20">
      {/* Navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="fixed top-0 w-full z-50 border-b border-white/10 backdrop-blur-md bg-background/40"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-blue-400" />
            <span className="text-xl font-bold">NEXS AI</span>
          </div>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button className="bg-blue-600 hover:bg-blue-700">Sign In</Button>
            </a>
          )}
        </div>
      </motion.nav>

      {/* Hero Section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="pt-32 pb-20 px-4 sm:px-6 lg:px-8"
      >
        <div className="max-w-7xl mx-auto">
          <motion.div variants={itemVariants} className="text-center mb-12">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Your AI Memory Operating System
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Capture, organize, and leverage everything you know. NEXS AI is your second brain—intelligently storing conversations, ideas, goals, and insights.
            </p>
          </motion.div>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                Get Started <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
            <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10 text-lg px-8">
              Learn More
            </Button>
          </motion.div>

          {/* Feature Cards */}
          <motion.div
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20"
          >
            {[
              {
                icon: Brain,
                title: "Memory Engine",
                description: "Automatically store and organize all your memories with smart tagging",
              },
              {
                icon: MessageSquare,
                title: "AI Chat",
                description: "Conversational interface that understands your context and history",
              },
              {
                icon: Network,
                title: "Knowledge Graph",
                description: "Visualize connections between people, ideas, and projects",
              },
              {
                icon: Zap,
                title: "Smart Insights",
                description: "AI-generated summaries, patterns, and actionable suggestions",
              },
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                variants={itemVariants}
                whileHover={{ scale: 1.05, y: -5 }}
                className="p-6 rounded-2xl bg-background/40 backdrop-blur-md border border-white/10 hover:border-blue-400/30 transition-all"
              >
                <feature.icon className="h-8 w-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Features Section */}
          <motion.div variants={itemVariants} className="mb-20">
            <h2 className="text-3xl font-bold text-center mb-12">Everything You Need</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  title: "Universal Search",
                  description: "Find anything across all your memories with natural language queries",
                },
                {
                  title: "Project Workspaces",
                  description: "Organize work into dedicated spaces with integrated chat and files",
                },
                {
                  title: "Task & Goal Tracking",
                  description: "Manage tasks, goals, and habits with AI-powered insights",
                },
                {
                  title: "Memory Timeline",
                  description: "Explore your memories chronologically with rich filtering",
                },
                {
                  title: "Premium Design",
                  description: "Beautiful glassmorphism UI with smooth animations",
                },
                {
                  title: "Privacy First",
                  description: "Your data is yours. Full control over memory privacy and exports",
                },
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  variants={itemVariants}
                  className="flex gap-4 p-4 rounded-lg bg-white/5 border border-white/10"
                >
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-blue-600/20">
                      <ArrowRight className="h-5 w-5 text-blue-400" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            variants={itemVariants}
            className="text-center p-12 rounded-2xl bg-gradient-to-r from-blue-600/20 to-purple-600/20 border border-white/10 backdrop-blur-md"
          >
            <h2 className="text-3xl font-bold mb-4">Ready to Build Your Second Brain?</h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of users who are already using NEXS AI to capture, organize, and leverage their knowledge.
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                Start Free <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
          </motion.div>
        </div>
      </motion.section>

      {/* Footer */}
      <motion.footer
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="border-t border-white/10 bg-background/40 backdrop-blur-md py-8"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="flex items-center gap-2 mb-4 sm:mb-0">
              <Brain className="h-6 w-6 text-blue-400" />
              <span className="font-semibold">NEXS AI</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2026 NEXS AI. All rights reserved.
            </p>
          </div>
        </div>
      </motion.footer>
    </div>
  );
}
