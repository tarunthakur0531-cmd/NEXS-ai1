import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Plus, MessageSquare, Zap, Archive, Trash2, Pin } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Streamdown } from "streamdown";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

export default function Chat() {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch conversations
  const { data: conversations } = trpc.conversation.list.useQuery();
  const { data: currentMessages } = trpc.message.listByConversation.useQuery(
    selectedConversation || "",
    { enabled: !!selectedConversation }
  );

  // Mutations
  const createConversationMutation = trpc.conversation.create.useMutation();
  const createMessageMutation = trpc.message.create.useMutation();

  // Update messages when fetched
  useEffect(() => {
    if (currentMessages) {
      setMessages(
        currentMessages.map((m) => ({
          id: m.id,
          role: m.role,
          content: m.content,
          createdAt: new Date(m.createdAt),
        }))
      );
    }
  }, [currentMessages]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleNewConversation = async () => {
    const conversation = await createConversationMutation.mutateAsync({
      title: `Chat - ${new Date().toLocaleString()}`,
    });
    if (conversation) {
      setSelectedConversation(conversation.id);
      setMessages([]);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !selectedConversation) return;

    const userMessage = input;
    setInput("");
    setIsLoading(true);

    try {
      // Add user message
      const userMsg = await createMessageMutation.mutateAsync({
        conversationId: selectedConversation,
        role: "user",
        content: userMessage,
      });

      if (userMsg) {
        setMessages((prev) => [
          ...prev,
          {
            id: userMsg.id,
            role: "user",
            content: userMessage,
            createdAt: new Date(),
          },
        ]);
      }

      // Simulate AI response (in production, this would call the LLM API)
      const aiResponse = `I received your message: "${userMessage}". This is a placeholder response. In production, this would be powered by the Manus built-in LLM with memory awareness.`;

      const assistantMsg = await createMessageMutation.mutateAsync({
        conversationId: selectedConversation,
        role: "assistant",
        content: aiResponse,
      });

      if (assistantMsg) {
        setMessages((prev) => [
          ...prev,
          {
            id: assistantMsg.id,
            role: "assistant",
            content: aiResponse,
            createdAt: new Date(),
          },
        ]);
      }
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="flex h-[calc(100vh-120px)] gap-4">
        {/* Sidebar - Conversations */}
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="w-64 bg-background/40 backdrop-blur-md border border-white/10 rounded-2xl p-4 flex flex-col"
        >
          <Button
            onClick={handleNewConversation}
            className="w-full mb-4 bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Chat
          </Button>

          <ScrollArea className="flex-1">
            <div className="space-y-2">
              {conversations?.map((conv) => (
                <motion.button
                  key={conv.id}
                  whileHover={{ x: 4 }}
                  onClick={() => setSelectedConversation(conv.id)}
                  className={`w-full text-left p-3 rounded-lg transition-all ${
                    selectedConversation === conv.id
                      ? "bg-blue-500/20 border border-blue-400/50"
                      : "hover:bg-white/5 border border-transparent"
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <MessageSquare className="h-4 w-4 text-blue-400" />
                    {conv.isPinned && <Pin className="h-3 w-3 text-yellow-400" />}
                  </div>
                  <p className="text-sm font-medium truncate">{conv.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(conv.lastMessageAt || conv.createdAt).toLocaleDateString()}
                  </p>
                </motion.button>
              ))}
            </div>
          </ScrollArea>
        </motion.div>

        {/* Main Chat Area */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex-1 flex flex-col bg-background/40 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden"
        >
          {selectedConversation ? (
            <>
              {/* Messages Area */}
              <ScrollArea className="flex-1 p-6">
                <div className="space-y-4">
                  <AnimatePresence>
                    {messages.length === 0 && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="flex flex-col items-center justify-center h-96 text-center"
                      >
                        <Zap className="h-16 w-16 text-blue-400/30 mb-4" />
                        <h3 className="text-xl font-semibold mb-2">Start a conversation</h3>
                        <p className="text-muted-foreground">
                          Ask me anything about your memories, goals, or ideas
                        </p>
                      </motion.div>
                    )}

                    {messages.map((message, idx) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-md lg:max-w-2xl px-4 py-3 rounded-2xl ${
                            message.role === "user"
                              ? "bg-blue-600/30 border border-blue-400/30 text-foreground"
                              : "bg-purple-600/20 border border-purple-400/30 text-foreground"
                          }`}
                        >
                          {message.role === "assistant" ? (
                            <Streamdown>{message.content}</Streamdown>
                          ) : (
                            <p className="text-sm">{message.content}</p>
                          )}
                          <p className="text-xs text-muted-foreground mt-2">
                            {message.createdAt.toLocaleTimeString()}
                          </p>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {isLoading && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex justify-start"
                    >
                      <div className="bg-purple-600/20 border border-purple-400/30 px-4 py-3 rounded-2xl">
                        <div className="flex gap-2">
                          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-100" />
                          <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200" />
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <div ref={scrollRef} />
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="border-t border-white/10 p-4 bg-background/20">
                <form onSubmit={handleSendMessage} className="flex gap-3">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask me anything..."
                    disabled={isLoading}
                    className="flex-1 bg-background/40 border-white/10 focus:border-blue-400/50 rounded-full"
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !input.trim()}
                    className="bg-blue-600 hover:bg-blue-700 rounded-full"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center"
              >
                <MessageSquare className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No conversation selected</h3>
                <p className="text-muted-foreground mb-4">
                  Create a new chat or select one from the sidebar
                </p>
                <Button onClick={handleNewConversation} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Start New Chat
                </Button>
              </motion.div>
            </div>
          )}
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
